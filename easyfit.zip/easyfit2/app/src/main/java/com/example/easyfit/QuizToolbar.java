package com.example.easyfit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class QuizToolbar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_toolbar);
    }
}